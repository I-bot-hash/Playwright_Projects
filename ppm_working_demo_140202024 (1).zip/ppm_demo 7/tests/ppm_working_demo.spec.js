const {
    test,
    expect
} = require('@playwright/test');

const credentials = require('./credentials.json');
const {
    getDate
} = require('./utils/Generic_utils');
const {
    locatorToBePresent,
    countNoOfChildElements
} = require('./utils/Locators_utils');

const {
    getWeekRange
} = require('./utils/ppm_utils');
const ppm_URL = require('./env.json');
var timesheet_rows = require("./timesheet_Multiplerows.json");
var Drafted_timesheets_date = require("./timesheet_draft_data.json");
var Pro_AssignByManager = require("./Assigned_project_data");
var Project_dtl = Pro_AssignByManager["ProjectsToBeAssignByManager"];

function trimlocator(Project_loc) {
    Project_loc = Project_loc + '';
    Project_loc = Project_loc.split("').locator('").join(' ');
    Project_loc = Project_loc.substring("locator('".length).replace(/'\)$/, '');
    return Project_loc;
  }
    
const URL = ppm_URL.URL;
var projects_assign = require("./assignedProjects.json");
var assign_projects = projects_assign["assignedProjects"];

const ppm_login = test.extend({
    pageFixture: async({page},use)=>{
        const username1 = credentials["succesfulLogin"]["Username"];
    const password1 = credentials["succesfulLogin"]["Password"];
    page.goto(URL);
    // Fill in the login form
    await expect(page.locator('input[name="email_id"]')).toBeEditable();
    await page.locator('input[name="email_id"]').fill(username1);
    await expect(page.locator('input[name="pswd"]')).toBeEditable();
    await page.locator('input[name="pswd"]').fill(password1);
    await page.waitForTimeout(1000);
    await expect(page.locator('.button.blue.gradient')).toBeEnabled();
    await page.locator('.button.blue.gradient').click();
    await page.waitForTimeout(5000);
    await expect(page.locator('id=btnTimeSheet-btnInnerEl')).toBeVisible();
    await page.locator('id=btnTimeSheet-btnInnerEl').click();
    await expect(page.locator('id=btnTimeSheetEntry-textEl')).toBeVisible();
    await page.locator('id=btnTimeSheetEntry-textEl').click();
    await expect(page.locator('id=cmbTSEntry_SelectWeek-trigger-picker')).toBeVisible();
    await page.locator('id=cmbTSEntry_SelectWeek-trigger-picker').click();
    
    await use(page);
    }
});

test.skip('login test failure due to username', async({
        page
    }) => {
    const username2 = credentials["invalidLoginViaWrongUsername"]["Username"];
    const password2 = credentials["succesfulLogin"]["Password"];
    await page.goto(URL);
    // Fill in the login form
    await expect(page.locator('input[name="email_id"]')).toBeEditable();
    await page.locator('input[name="email_id"]').fill(username2);
    await expect(page.locator('input[name="pswd"]')).toBeEditable();
    await page.locator('input[name="pswd"]').fill(password2);
    await page.waitForTimeout(1000);
    await expect(page.locator('.button.blue.gradient')).toBeEnabled();
    await page.locator('.button.blue.gradient').click();
    await page.waitForTimeout(2000);
});

test.skip('login test failure due to password', async({
        page
    }) => {
    const username3 = credentials["succesfulLogin"]["Username"];
    const password3 = credentials["invalidLoginViaWrongPassword"]["Password"];
    await page.goto(URL);
    // Fill in the login form
    await expect(page.locator('input[name="email_id"]')).toBeEditable();
    await page.locator('input[name="email_id"]').fill(username3);
    await expect(page.locator('input[name="pswd"]')).toBeEditable();
    await page.locator('input[name="pswd"]').fill(password3);
    await page.waitForTimeout(1000);
    await expect(page.locator('.button.blue.gradient')).toBeEnabled();
    await page.locator('.button.blue.gradient').click();
    await page.waitForTimeout(2000);
});

ppm_login.skip('login test success', async({
        pageFixture
    }) => {
    await pageFixture.waitForTimeout(2000);

});

ppm_login('timesheet entry', async({
    pageFixture
}) => {



let dateofweek = timesheet_rows["Data_used"];
let startdate;

for(let ts=0; ts<dateofweek.length; ts++){
   
    let sumOftotalHrs = 0;
    
    startdate = dateofweek[ts]["selectedDate"];
    console.log("stardate: "+JSON.stringify(startdate));
    let selectedDate = getWeekRange(startdate);
let timesheetRows_conter = dateofweek[ts]["projectData"];   
await expect.soft(pageFixture.getByRole('option', {
        name: selectedDate
    })).toBeVisible();
await pageFixture.waitForTimeout(2000);
await pageFixture.getByRole('option', {
    name: selectedDate
}).click();

let tb_counter =1;
let Prj_count = {};

for (let i = 0; i < timesheetRows_conter.length; i++) {
    //await pageFixture.locator('table[data-recordindex="' + i + '"] > tbody > .x-grid-row > .x-grid-cell.x-grid-td.x-grid-cell-gridcolumn-1078.x-unselectable > .x-grid-cell-inner').click();
    let td =2;
    let loc1 = pageFixture.locator('#gridTSEntry-body');
    await expect(loc1).toBeVisible();
    let loc2=loc1.locator('> div:nth-child(1)');
    await expect(loc2).toBeVisible();
    let loc3 = loc2.locator('> div:nth-child(2)');
    await expect(loc3).toBeVisible();
    let loc4 = loc3.locator(`> table:nth-child(${tb_counter})`);
    await expect(loc4).toBeVisible();
    let loc5 = loc4.locator('> tbody');
    await expect(loc5).toBeVisible();
    let loc6 = loc5.locator('> tr:nth-child(1)');
    await expect(loc6).toBeVisible();
    let loc7 = loc6.locator('> td:nth-child(2)');
    await expect(loc7).toBeVisible();
    let loc8 = loc7.locator('> div:nth-child(1)');
    await expect(loc8).toBeVisible();
    await pageFixture.locator(`#gridTSEntry-body > div:nth-child(1) > div:nth-child(2) >  table:nth-child(${tb_counter}) > tbody > tr:nth-child(1) > td:nth-child(${td++}) > div:nth-child(1)`).click();

    await expect.soft(pageFixture.locator('#TSEntryGrd_cmbProject-trigger-picker')).toBeVisible();
    await pageFixture.locator('#TSEntryGrd_cmbProject-trigger-picker').click();
    var pro_name = timesheetRows_conter[i]["Project"];
    if (Prj_count[pro_name] == undefined) {
        // If not present in the array
        var Project_name_counter = await pageFixture.locator('text=' + timesheetRows_conter[i]["Project"]).nth(0);
        var pro_name_content = await Project_name_counter.textContent();
        Prj_count[pro_name_content] = 0;
        await expect.soft(pageFixture.getByText(timesheetRows_conter[i]["Project"]).nth(Prj_count[pro_name_content])).toBeEnabled();
        await pageFixture.getByText(timesheetRows_conter[i]["Project"]).nth(Prj_count[pro_name_content]).click();
    } else {
        Prj_count[pro_name] = Number(Prj_count[pro_name]) + 1;
        await pageFixture.waitForTimeout(2000);
        var Project_name_counter = await pageFixture.locator('text=' + timesheetRows_conter[i]["Project"]).nth(Prj_count[pro_name]);
        await pageFixture.waitForTimeout(2000);
        console.log("Project_name_counter: "+JSON.stringify(Project_name_counter));
        var pro_name_content = await Project_name_counter.textContent();
        await expect.soft(pageFixture.getByText(timesheetRows_conter[i]["Project"]).nth(Prj_count[pro_name_content])).toBeEnabled();
        await pageFixture.getByText(timesheetRows_conter[i]["Project"]).nth(Prj_count[pro_name_content]).click();
    }
    await pageFixture.locator(`#gridTSEntry-body > div:nth-child(1) > div:nth-child(2) >  table:nth-child(${tb_counter}) > tbody > tr:nth-child(1) > td:nth-child(${td++}) > div:nth-child(1)`).click();
    await expect.soft(pageFixture.locator('#combobox-1395-trigger-picker')).toBeEnabled();
    await pageFixture.locator('#combobox-1395-trigger-picker').click();
    await expect.soft(pageFixture.getByRole('option', {
            name: timesheetRows_conter[i]["Task"]
        })).toBeEnabled();
    await pageFixture.getByRole('option', {
        name: timesheetRows_conter[i]["Task"],
        exact: true
    }).scrollIntoViewIfNeeded();
    await pageFixture.getByRole('option', {
        name: timesheetRows_conter[i]["Task"],
        exact: true
    }).click();
    await pageFixture.locator(`#gridTSEntry-body > div:nth-child(1) > div:nth-child(2) >  table:nth-child(${tb_counter}) > tbody > tr:nth-child(1) > td:nth-child(${td++}) > div:nth-child(1)`).click();
    await expect.soft(pageFixture.locator('#combobox-1398-trigger-picker')).toBeEnabled();
    await pageFixture.locator('#combobox-1398-trigger-picker').click();
    await expect.soft(pageFixture.getByRole('option', {
            name: timesheetRows_conter[i]["Module"]
        })).toBeEnabled();
    await pageFixture.getByRole('option', {
        name: timesheetRows_conter[i]["Module"],
        exact: true
    }).scrollIntoViewIfNeeded();
    // Now, click on the element
    await pageFixture.getByRole('option', {
        name: timesheetRows_conter[i]["Module"],
        exact: true
    }).click();
    await pageFixture.locator(`#gridTSEntry-body > div:nth-child(1) > div:nth-child(2) >  table:nth-child(${tb_counter}) > tbody > tr:nth-child(1) > td:nth-child(${td++}) > div:nth-child(1)`).click();
    await expect.soft(pageFixture.getByRole('row', {
            name: timesheetRows_conter[i]["Project"]
        }).getByLabel('')).toBeVisible();
    await pageFixture.getByRole('row', {
        name: timesheetRows_conter[i]["Project"]
    }).getByLabel('').fill(timesheetRows_conter[i]["Artifact"]);
    await pageFixture.locator(`#gridTSEntry-body > div:nth-child(1) > div:nth-child(2) >  table:nth-child(${tb_counter}) > tbody > tr:nth-child(1) > td:nth-child(${td++}) > div:nth-child(1)`).click();
    console.log(" before if td: "+td);
    td+=2;
    await pageFixture.getByRole('row', {
        name: timesheetRows_conter[i]["Project"]
    }).getByLabel('').fill(timesheetRows_conter[i]["Remarks"]);
    if (timesheetRows_conter[i]["hrs"][0] != 0) {
        console.log("td: "+td);
        await pageFixture.locator(`#gridTSEntry-body > div:nth-child(1) > div:nth-child(2) >  table:nth-child(${tb_counter}) > tbody > tr:nth-child(1) > td:nth-child(${td}) > div:nth-child(1)`).first().click();
        await expect.soft(pageFixture.getByRole('row', {
                name: timesheetRows_conter[i]["Project"]
            }).getByLabel('')).toBeVisible();
        await pageFixture.getByRole('row', {
            name: timesheetRows_conter[i]["Project"]
        }).getByLabel('').fill(""+timesheetRows_conter[i]["hrs"][0]);
        sumOftotalHrs+=Number(timesheetRows_conter[i]["hrs"][0]);
        
    }
    td+=2;
    if (timesheetRows_conter[i]["hrs"][1] != 0) {
        console.log("td: "+td);
        await pageFixture.locator(`#gridTSEntry-body > div:nth-child(1) > div:nth-child(2) >  table:nth-child(${tb_counter}) > tbody > tr:nth-child(1) > td:nth-child(${td}) > div:nth-child(1)`).first().click();
        await expect.soft(pageFixture.getByRole('row', {
                name: timesheetRows_conter[i]["Project"]
            }).getByLabel('')).toBeVisible();
        await pageFixture.getByRole('row', {
            name: timesheetRows_conter[i]["Project"]
        }).getByLabel('').fill(""+timesheetRows_conter[i]["hrs"][1]);
        sumOftotalHrs+=Number(timesheetRows_conter[i]["hrs"][1]);
       
    }
    td+=2;
    if (timesheetRows_conter[i]["hrs"][2] != 0) {
        console.log("td: "+td);
        await pageFixture.locator(`#gridTSEntry-body > div:nth-child(1) > div:nth-child(2) >  table:nth-child(${tb_counter}) > tbody > tr:nth-child(1) > td:nth-child(${td}) > div:nth-child(1)`).first().click();
        await expect.soft(pageFixture.getByRole('row', {
                name: timesheetRows_conter[i]["Project"]
            }).getByLabel('')).toBeVisible();
        await pageFixture.getByRole('row', {
            name: timesheetRows_conter[i]["Project"]
        }).getByLabel('').fill(""+timesheetRows_conter[i]["hrs"][2]);
        sumOftotalHrs+=Number(timesheetRows_conter[i]["hrs"][2]);
  
    }
    td+=2;
    if (timesheetRows_conter[i]["hrs"][3] != 0) {
        console.log("td: "+td);
        await pageFixture.locator(`#gridTSEntry-body > div:nth-child(1) > div:nth-child(2) >  table:nth-child(${tb_counter}) > tbody > tr:nth-child(1) > td:nth-child(${td}) > div:nth-child(1)`).first().click();
        await expect.soft(pageFixture.getByRole('row', {
                name: timesheetRows_conter[i]["Project"]
            }).getByLabel('')).toBeVisible();
        await pageFixture.getByRole('row', {
            name: timesheetRows_conter[i]["Project"]
        }).getByLabel('').fill(""+timesheetRows_conter[i]["hrs"][3]);
        sumOftotalHrs+=Number(timesheetRows_conter[i]["hrs"][3]);
       
    }
    td+=2;
    if (timesheetRows_conter[i]["hrs"][4] != 0) {
        await pageFixture.locator(`#gridTSEntry-body > div:nth-child(1) > div:nth-child(2) >  table:nth-child(${tb_counter}) > tbody > tr:nth-child(1) > td:nth-child(${td}) > div:nth-child(1)`).first().click();
        await expect.soft(pageFixture.getByRole('row', {
                name: timesheetRows_conter[i]["Project"]
            }).getByLabel('')).toBeVisible();
        await pageFixture.getByRole('row', {
            name: timesheetRows_conter[i]["Project"]
        }).getByLabel('').fill(""+timesheetRows_conter[i]["hrs"][4]);
        sumOftotalHrs+=Number(timesheetRows_conter[i]["hrs"][4]);
        
    }
  
    await expect.soft(pageFixture.locator('#tableview-1099')).toBeEnabled();
    await pageFixture.locator('#tableview-1099').click();
    if (i < timesheetRows_conter.length - 1) {
        await expect.soft(pageFixture.locator("#btnTSEntry_AddNewRow-btnIconEl")).toBeEnabled();
        await pageFixture.locator("#btnTSEntry_AddNewRow-btnIconEl").click();
    }
    tb_counter++;
}
await expect.soft(pageFixture.locator('#lblTimeSheetEntry')).toBeEnabled();
const ttl_hrs_element = await pageFixture.locator('#component-1113-item > tbody > .x-grid-row-summary > .x-grid-cell.x-grid-td.x-grid-cell-numbercolumn-1098.x-grid-cell-last.x-unselectable > .x-grid-cell-inner ');
const textContent = await ttl_hrs_element.textContent();
const Total_hrs = parseInt(textContent, 10);
console.log("Total_hrs :" + Total_hrs);
console.log("Sum of hours: "+sumOftotalHrs)
if (sumOftotalHrs !== Total_hrs) {
    await expect(true).toBe(false, "Hours not equal");
} else {
    await expect(true).toBe(true, "Total Hours match");

    if (Total_hrs >= 40) {
        await expect(pageFixture.locator('#btnSubmitTS')).toBeEnabled();
        await pageFixture.locator('#btnSubmitTS').click();
        //await pageFixture.locator('#btnTSEntryDiscardYes-btnInnerEl').click();
    }
}
await pageFixture.waitForTimeout(1000);
await pageFixture.reload();
await pageFixture.locator('id=button-1025-btnInnerEl').click();
const username1 = credentials["succesfulLogin"]["Username"];
const password1 = credentials["succesfulLogin"]["Password"];
pageFixture.goto(URL);
// Fill in the login form
await expect(pageFixture.locator('input[name="email_id"]')).toBeEditable();
await pageFixture.locator('input[name="email_id"]').fill(username1);
await expect(pageFixture.locator('input[name="pswd"]')).toBeEditable();
await pageFixture.locator('input[name="pswd"]').fill(password1);
await pageFixture.waitForTimeout(1000);
await expect(pageFixture.locator('.button.blue.gradient')).toBeEnabled();
await pageFixture.locator('.button.blue.gradient').click();
await pageFixture.waitForTimeout(1000);
await expect(pageFixture.locator('id=btnTimeSheet-btnInnerEl')).toBeVisible();
await pageFixture.locator('id=btnTimeSheet-btnInnerEl').click();
await expect(pageFixture.locator('id=btnTimeSheetEntry-textEl')).toBeVisible();
await pageFixture.locator('id=btnTimeSheetEntry-textEl').click();
await pageFixture.waitForTimeout(1000);
await expect(pageFixture.locator('id=cmbTSEntry_SelectWeek-trigger-picker')).toBeVisible();
await pageFixture.locator('id=cmbTSEntry_SelectWeek-trigger-picker').click();


}


});

ppm_login.skip('Project Entry', async({
        pageFixture
    }) => {
    let datesForPro = getDate(Project_dtl);
    await pageFixture.getByRole('option', {
        name: Project_dtl.ProjectWeek
    }).click();
    await pageFixture.locator('.x-grid-item > tbody > .x-grid-row > .x-grid-cell.x-grid-td.x-grid-cell-gridcolumn-1078.x-unselectable > .x-grid-cell-inner').click();
    await expect.soft(pageFixture.locator('#TSEntryGrd_cmbProject-trigger-picker')).toBeVisible();
    await pageFixture.locator('#TSEntryGrd_cmbProject-trigger-picker').click();
    await expect.soft(pageFixture.getByText('Add New Project')).toBeEnabled();
    await pageFixture.getByText('Add New Project').click();
    await expect.soft(pageFixture.locator('#cmbAddProjectManager-trigger-picker')).toBeVisible();
    await pageFixture.locator('#cmbAddProjectManager-trigger-picker').click();
    await pageFixture.getByLabel('Manager').fill(Project_dtl.Manager);
    await pageFixture.getByRole('option', {
        name: Project_dtl.Manager
    }).click();
    await expect.soft(pageFixture.locator('#dateAddProjectFromDate-trigger-picker')).toBeVisible();
    await pageFixture.locator('#dateAddProjectFromDate-trigger-picker').click();
    await pageFixture.getByText('18', {
        exact: true
    }).click();
    await expect.soft(pageFixture.getByRole('button', {
            name: 'View'
        })).toBeEnabled();
    await pageFixture.getByRole('button', {
        name: 'View'
    }).click();
    await pageFixture.getByRole('option', {
        name: Project_dtl.Project
    }).click();
    await pageFixture.getByLabel('Add to Selected').click();
    await pageFixture.locator('#dateAddProjectFromDate-trigger-picker').click();
    await pageFixture.locator('.x-datepicker-month > .x-btn.x-unselectable.x-btn-default-small').nth(0).click();
    await pageFixture.getByRole('button', {
        name: Project_dtl.FromDate.substring(7),
        exact: true
    }).click();
    await pageFixture.getByRole('button', {
        name: Project_dtl.FromDate.substring(3, 6),
        exact: true
    }).click();
    await expect.soft(pageFixture.getByRole('button', {
            name: 'OK'
        })).toBeEnabled();
    await pageFixture.getByRole('button', {
        name: 'OK'
    }).click();
    await pageFixture.getByLabel('' + datesForPro["useDate1"]).getByText('' + datesForPro["dateNumber1"]).click();
    await pageFixture.locator('#dateAddProjectToDate-trigger-picker').click();
    await pageFixture.locator('.x-datepicker-month > .x-btn.x-unselectable.x-btn-default-small').nth(1).click();
    await pageFixture.getByRole('button', {
        name: Project_dtl.ToDate.substring(7),
        exact: true
    }).click();
    await pageFixture.getByRole('button', {
        name: Project_dtl.ToDate.substring(3, 6),
        exact: true
    }).click();
    await expect.soft(pageFixture.getByRole('button', {
            name: 'OK'
        })).toBeEnabled();
    await pageFixture.getByRole('button', {
        name: 'OK'
    }).click();
    await pageFixture.getByLabel('' + datesForPro["useDate2"]).getByText('' + datesForPro["dateNumber2"]).click();
    await expect.soft(pageFixture.getByRole('button', {
            name: 'View'
        })).toBeEnabled();
    await pageFixture.getByRole('button', {
        name: 'View'
    }).click();
    await pageFixture.getByRole('option', {
        name: Project_dtl.Project
    }).click();
    await pageFixture.locator('.x-btn-icon-el.x-btn-icon-el-default-small.x-form-itemselector-add').click();
    await pageFixture.waitForTimeout(2000);
    //await pageFixture.locator('#btnAddProjectCreate-btnInnerEl').click();
    await pageFixture.waitForTimeout(2000);
});

ppm_login('timesheet in draft state', async({
        pageFixture
    }) => {
    
    
    
    let dateofweek = Drafted_timesheets_date["draft_week"];
    let startdate;
   
    for(let ts=0; ts<dateofweek.length; ts++){

        if(ts!=0){
            await expect(pageFixture.locator('#fieldSetTSEntrySelectWeek-legendToggle-toolEl')).toBeVisible();
            await pageFixture.locator('#fieldSetTSEntrySelectWeek-legendToggle-toolEl').click();
        }
        
    
        
        startdate = dateofweek[ts]["selectedDate"];
       
        let selectedDate = getWeekRange(startdate);
        
    console.log("ts before dropdown: "+ts);
    if(ts!=0){
        console.log("inside ts if");
        let date_dropdown_parent1 = pageFixture.locator('#cmbTSEntry_SelectWeek-trigger-picker');
        await expect(date_dropdown_parent1).toBeVisible();
        await date_dropdown_parent1.click();
       
    }
    
    let date_dropdown = pageFixture.getByRole('option', { name: selectedDate});
    await expect(date_dropdown).toBeVisible();
    await date_dropdown.click();
    

    let tb_counter =1;
   
    try{
    for (let i = 0; i >= 0; i++) {
        

        //project
        let Project_loc1 = pageFixture.locator('#gridTSEntry-body');
        await expect(Project_loc1).toBeVisible();
        let Project_loc2=Project_loc1.locator('> div:nth-child(1)');
        await expect(Project_loc2).toBeVisible();
        let Project_loc3 = Project_loc2.locator('> div:nth-child(2)');
        await expect(Project_loc3).toBeVisible();
        let Project_loc4 = Project_loc3.locator(`> table:nth-child(${tb_counter})`);
        await expect(Project_loc4).toBeVisible();
        let Project_loc5 = Project_loc4.locator('> tbody');
        await expect(Project_loc5).toBeVisible();
        let Project_loc6 = Project_loc5.locator('> tr:nth-child(1)');
        await expect(Project_loc6).toBeVisible();
        let Project_loc7 = Project_loc6.locator(`> td:nth-child(2)`);
        await expect(Project_loc7).toBeVisible();
        let Project_loc8 =  Project_loc7.locator('> div:nth-child(1)');
        await expect(Project_loc8).toBeVisible();
        await Project_loc8.click();
        Project_loc8 = trimlocator(Project_loc8);
        console.log("Project_loc8:" +Project_loc8);
        
        let inputElement = await pageFixture.locator(
            Project_loc8
          ).first();
            
        console.log("input element: "+inputElement);
        let inputValue = await inputElement.textContent();

        console.log("Input Value: "+inputValue);
        console.log("Project locator completed");
        await pageFixture.waitForTimeout(1000);
       

        //task
        let task_loc1 = pageFixture.locator('#gridTSEntry-body');
        await expect(task_loc1).toBeVisible();
        let task_loc2=task_loc1.locator('> div:nth-child(1)');
        await expect(task_loc2).toBeVisible();
        let task_loc3 = task_loc2.locator('> div:nth-child(2)');
        await expect(task_loc3).toBeVisible();
        let task_loc4 = task_loc3.locator(`> table:nth-child(${tb_counter})`);
        await expect(task_loc4).toBeVisible();
        let task_loc5 = task_loc4.locator('> tbody');
        await expect(task_loc5).toBeVisible();
        let task_loc6 = task_loc5.locator('> tr:nth-child(1)');
        await expect(task_loc6).toBeVisible();
        let task_loc7 = task_loc6.locator(`> td:nth-child(3)`);
        await expect(task_loc7).toBeVisible();
        let task_loc8 = task_loc7.locator('> div:nth-child(1)');
        await expect(task_loc8).toBeVisible();
        await task_loc8.click();
        task_loc8 = trimlocator(task_loc8);
        console.log("task_loc8:" +task_loc8);
     
        inputElement = await pageFixture.locator(
            task_loc8
          ).first();
            
        console.log("input element: "+inputElement);
        inputValue = await inputElement.textContent();
       
        console.log("Input Value: "+inputValue);
        await pageFixture.waitForTimeout(1000);        
        console.log("task locator completed");
        
        

        //Module
        let Mod_loc1 = pageFixture.locator('#gridTSEntry-body');
        await expect(Mod_loc1).toBeVisible();
        let Mod_loc2=Mod_loc1.locator('> div:nth-child(1)');
        await expect(Mod_loc2).toBeVisible();
        let Mod_loc3 = Mod_loc2.locator('> div:nth-child(2)');
        await expect(Mod_loc3).toBeVisible();
        let Mod_loc4 = Mod_loc3.locator(`> table:nth-child(${tb_counter})`);
        await expect(Mod_loc4).toBeVisible();
        let Mod_loc5 = Mod_loc4.locator('> tbody');
        await expect(Mod_loc5).toBeVisible();
        let Mod_loc6 = Mod_loc5.locator('> tr:nth-child(1)');
        await expect(Mod_loc6).toBeVisible();
        let Mod_loc7 = Mod_loc6.locator(`> td:nth-child(4)`);
        await expect(Mod_loc7).toBeVisible();
        let Mod_loc8 = Mod_loc7.locator('> div:nth-child(1)');
        await expect(Mod_loc8).toBeVisible();
        await Mod_loc8.click();
        Mod_loc8 = trimlocator(Mod_loc8);
        console.log("Mod_loc8:" +Mod_loc8);
        
        inputElement = await pageFixture.locator(
            Mod_loc8
          ).first();
            
        console.log("input element: "+inputElement);
        inputValue = await inputElement.textContent();
        
        console.log("Input Value: "+inputValue);
        await pageFixture.waitForTimeout(1000);        
        console.log("mod locator completed");
        

        //Artifact
        let Art_loc1 = pageFixture.locator('#gridTSEntry-body');
        await expect(Art_loc1).toBeVisible();
        let Art_loc2=Art_loc1.locator('> div:nth-child(1)');
        await expect(Art_loc2).toBeVisible();
        let Art_loc3 = Art_loc2.locator('> div:nth-child(2)');
        await expect(Art_loc3).toBeVisible();
        let Art_loc4 = Art_loc3.locator(`> table:nth-child(${tb_counter})`);
        await expect(Art_loc4).toBeVisible();
        let Art_loc5 = Art_loc4.locator('> tbody');
        await expect(Art_loc5).toBeVisible();
        let Art_loc6 = Art_loc5.locator('> tr:nth-child(1)');
        await expect(Art_loc6).toBeVisible();
        let Art_loc7 = Art_loc6.locator(`> td:nth-child(5)`);
        await expect(Art_loc7).toBeVisible();
        let Art_loc8 = Art_loc7.locator('> div:nth-child(1)');
        await expect(Art_loc8).toBeVisible();
        await Art_loc8.click();
        Art_loc8 = trimlocator(Art_loc8);
        console.log("Art_loc8:" +Art_loc8);
        
        inputElement = await pageFixture.locator(
            Art_loc8
          ).first();
            
        console.log("input element: "+inputElement);
        inputValue = await inputElement.textContent();
    
        console.log("Input Value: "+inputValue);
        await pageFixture.waitForTimeout(1000);        
        console.log("Art_loc8 locator completed");


        //Remarks
        let Rem_loc1 = pageFixture.locator('#gridTSEntry-body');
        await expect(Rem_loc1).toBeVisible();
        let Rem_loc2=Rem_loc1.locator('> div:nth-child(1)');
        await expect(Rem_loc2).toBeVisible();
        let Rem_loc3 = Rem_loc2.locator('> div:nth-child(2)');
        await expect(Rem_loc3).toBeVisible();
        let Rem_loc4 = Rem_loc3.locator(`> table:nth-child(${tb_counter})`);
        await expect(Rem_loc4).toBeVisible();
        let Rem_loc5 = Rem_loc4.locator('> tbody');
        await expect(Rem_loc5).toBeVisible();
        let Rem_loc6 = Rem_loc5.locator('> tr:nth-child(1)');
        await expect(Rem_loc6).toBeVisible();
        let Rem_loc7 = Rem_loc6.locator(`> td:nth-child(6)`);
        await expect(Rem_loc7).toBeVisible();
        let Rem_loc8 = Rem_loc7.locator('> div:nth-child(1)');
        await expect(Rem_loc8).toBeVisible();
        await Rem_loc8.click();
        Rem_loc8 = trimlocator(Rem_loc8);
        console.log("Rem_loc8:" +Rem_loc8);
        
        inputElement = await pageFixture.locator(
            Rem_loc8
          ).first();
            
        console.log("input element: "+inputElement);
        inputValue = await inputElement.textContent();
        
        console.log("Input Value: "+inputValue);
        await pageFixture.waitForTimeout(1000);        
        console.log("Rem_loc8 locator completed");

         
            
            //Monday
            let Mon_loc1 = pageFixture.locator('#gridTSEntry-body');
            await expect(Mon_loc1).toBeVisible();
            let Mon_loc2=Mon_loc1.locator('> div:nth-child(1)');
            await expect(Mon_loc2).toBeVisible();
            let Mon_loc3 = Mon_loc2.locator('> div:nth-child(2)');
            await expect(Mon_loc3).toBeVisible();
            let Mon_loc4 = Mon_loc3.locator(`> table:nth-child(${tb_counter})`);
            await expect(Mon_loc4).toBeVisible();
            let Mon_loc5 = Mon_loc4.locator('> tbody');
            await expect(Mon_loc5).toBeVisible();
            let Mon_loc6 = Mon_loc5.locator('> tr:nth-child(1)');
            await expect(Mon_loc6).toBeVisible();
            let Mon_loc7 = Mon_loc6.locator(`> td:nth-child(9)`);
            await expect(Mon_loc7).toBeVisible();
            let Mon_loc8 = Mon_loc7.locator('> div:nth-child(1)');
            await expect(Mon_loc8).toBeVisible();
            await Mon_loc8.click();
            Mon_loc8 = trimlocator(Mon_loc8);
            console.log("Mon_loc8:" +Mon_loc8);
       
                    inputElement = await pageFixture.locator(
                        Mon_loc8
                      ).first();
                        
                    console.log("input element: "+inputElement);
                    inputValue = await inputElement.textContent();
                  
                    console.log("Input Value: "+inputValue);
                    await pageFixture.waitForTimeout(1000);        
                    console.log("Mon_loc8 locator completed");

          
            //Tuesday
            let Tue_loc1 = pageFixture.locator('#gridTSEntry-body');
            await expect(Tue_loc1).toBeVisible();
            let Tue_loc2=Tue_loc1.locator('> div:nth-child(1)');
            await expect(Tue_loc2).toBeVisible();
            let Tue_loc3 = Tue_loc2.locator('> div:nth-child(2)');
            await expect(Tue_loc3).toBeVisible();
            let Tue_loc4 = Tue_loc3.locator(`> table:nth-child(${tb_counter})`);
            await expect(Tue_loc4).toBeVisible();
            let Tue_loc5 = Tue_loc4.locator('> tbody');
            await expect(Tue_loc5).toBeVisible();
            let Tue_loc6 = Tue_loc5.locator('> tr:nth-child(1)');
            await expect(Tue_loc6).toBeVisible();
            let Tue_loc7 = Tue_loc6.locator(`> td:nth-child(11)`);
            await expect(Tue_loc7).toBeVisible();
            let Tue_loc8 = Tue_loc7.locator('> div:nth-child(1)');
            await expect(Tue_loc8).toBeVisible();
            await Tue_loc8.click();
            Tue_loc8 = trimlocator(Tue_loc8);
            console.log("Tue_loc8:" +Tue_loc8);
                   
                    inputElement = await pageFixture.locator(
                        Tue_loc8
                      ).first();
                        
                    console.log("input element: "+inputElement);
                    inputValue = await inputElement.textContent();
                    
                    console.log("Input Value: "+inputValue);
                    await pageFixture.waitForTimeout(1000);        
                    console.log("Tue_loc8 locator completed");

        
            //Wednesday
            let Wed_loc1 = pageFixture.locator('#gridTSEntry-body');
            await expect(Wed_loc1).toBeVisible();
            let Wed_loc2=Wed_loc1.locator('> div:nth-child(1)');
            await expect(Wed_loc2).toBeVisible();
            let Wed_loc3 = Wed_loc2.locator('> div:nth-child(2)');
            await expect(Wed_loc3).toBeVisible();
            let Wed_loc4 = Wed_loc3.locator(`> table:nth-child(${tb_counter})`);
            await expect(Wed_loc4).toBeVisible();
            let Wed_loc5 = Wed_loc4.locator('> tbody');
            await expect(Wed_loc5).toBeVisible();
            let Wed_loc6 = Wed_loc5.locator('> tr:nth-child(1)');
            await expect(Wed_loc6).toBeVisible();
            let Wed_loc7 = Wed_loc6.locator(`> td:nth-child(13)`);
            await expect(Wed_loc7).toBeVisible();
            let Wed_loc8 = Wed_loc7.locator('> div:nth-child(1)');
            await expect(Wed_loc8).toBeVisible();
            await Wed_loc8.click();

        
            Wed_loc8 = trimlocator(Wed_loc8);
            console.log("Wed_loc8:" +Wed_loc8);
                    
                    inputElement = await pageFixture.locator(
                        Wed_loc8
                      ).first();
                        
                    console.log("input element: "+inputElement);
                    inputValue = await inputElement.textContent();
                    
                    console.log("Input Value: "+inputValue);
                    await pageFixture.waitForTimeout(1000);        
                    console.log("Wed_loc8 locator completed");      
       
            //Thursday
            let Thu_loc1 = pageFixture.locator('#gridTSEntry-body');
            await expect(Thu_loc1).toBeVisible();
            let Thu_loc2=Thu_loc1.locator('> div:nth-child(1)');
            await expect(Thu_loc2).toBeVisible();
            let Thu_loc3 = Thu_loc2.locator('> div:nth-child(2)');
            await expect(Thu_loc3).toBeVisible();
            let Thu_loc4 = Thu_loc3.locator(`> table:nth-child(${tb_counter})`);
            await expect(Thu_loc4).toBeVisible();
            let Thu_loc5 = Thu_loc4.locator('> tbody');
            await expect(Thu_loc5).toBeVisible();
            let Thu_loc6 = Thu_loc5.locator('> tr:nth-child(1)');
            await expect(Thu_loc6).toBeVisible();
            let Thu_loc7 = Thu_loc6.locator(`> td:nth-child(15)`);
            await expect(Thu_loc7).toBeVisible();
            let Thu_loc8 = Thu_loc7.locator('> div:nth-child(1)');
            await expect(Thu_loc8).toBeVisible();
            await Thu_loc8.click();
            Thu_loc8 = trimlocator(Thu_loc8);
            console.log("Thu_loc8:" +Thu_loc8);
                   
                    inputElement = await pageFixture.locator(
                        Thu_loc8
                      ).first();
                        
                    console.log("input element: "+inputElement);
                    inputValue = await inputElement.textContent();
               
                    console.log("Input Value: "+inputValue);
                    await pageFixture.waitForTimeout(1000);        
                    console.log("Thu_loc8 locator completed");
            
            //Friday
            let Fri_loc1 = pageFixture.locator('#gridTSEntry-body');
            await expect(Fri_loc1).toBeVisible();
            let Fri_loc2=Fri_loc1.locator('> div:nth-child(1)');
            await expect(Fri_loc2).toBeVisible();
            let Fri_loc3 = Fri_loc2.locator('> div:nth-child(2)');
            await expect(Fri_loc3).toBeVisible();
            let Fri_loc4 = Fri_loc3.locator(`> table:nth-child(${tb_counter})`);
            await expect(Fri_loc4).toBeVisible();
            let Fri_loc5 = Fri_loc4.locator('> tbody');
            await expect(Fri_loc5).toBeVisible();
            let Fri_loc6 = Fri_loc5.locator('> tr:nth-child(1)');
            await expect(Fri_loc6).toBeVisible();
            let Fri_loc7 = Fri_loc6.locator(`> td:nth-child(17)`);
            await expect(Fri_loc7).toBeVisible();
            let Fri_loc8 = Fri_loc7.locator('> div:nth-child(1)');
            await expect(Fri_loc8).toBeVisible();
            await Fri_loc8.click();
            Fri_loc8 = trimlocator(Fri_loc8);
            console.log("Fri_loc8:" +Fri_loc8);
                    
                    inputElement = await pageFixture.locator(
                        Fri_loc8
                      ).first();
                        
                    console.log("input element: "+inputElement);
                    inputValue = await inputElement.textContent();
                    
                    console.log("Input Value: "+inputValue);
                    await pageFixture.waitForTimeout(1000);        
                    console.log("Fri_loc8 locator completed"); 
        tb_counter++;
    }
}
    catch(e){
        //console.log(e);
    }
    
    await pageFixture.waitForTimeout(1000);


    }
    
    
});

ppm_login.skip('Assigned Projects verification', async({
        pageFixture
    }) => {
    let datesForPro = getDate(Project_dtl);
    let Assigned_project_list = [];
    const modifiedArray = assign_projects.map(project => project.split(' (')[0]);
    await pageFixture.getByRole('option', {
        name: Project_dtl.ProjectWeek
    }).click();
    await pageFixture.locator('.x-grid-item > tbody > .x-grid-row > .x-grid-cell.x-grid-td.x-grid-cell-gridcolumn-1078.x-unselectable > .x-grid-cell-inner').click();
    await pageFixture.locator('#TSEntryGrd_cmbProject-trigger-picker').click();
    let g = 0;
    let continueLoop = true;
    try {
        while (g >= 0 && continueLoop) {
            const element = await pageFixture.waitForSelector('li[data-boundview="TSEntryGrd_cmbProject-picker"][data-recordindex="' + g + '"]', {
                timeout: 1000
            }); // Adjust timeout value as needed
            const textContent = await element.textContent();
            console.log("textContent:" + textContent);
            Assigned_project_list.push(textContent);
            g++;
        }
    } catch (error) {
        //console.error("Error occurred while locating element:", error);
        // Remove the latest element from Assigned_project_list
        Assigned_project_list.pop();
        // Set continueLoop to false to exit the loop
        continueLoop = false;
    }
    await pageFixture.getByText('Add New Project').click();
    await pageFixture.locator('#cmbAddProjectManager-trigger-picker').click();
    await pageFixture.getByLabel('Manager').fill(Project_dtl.Manager);
    await pageFixture.getByRole('option', {
        name: Project_dtl.Manager
    }).click();
    await pageFixture.locator('#dateAddProjectFromDate-trigger-picker').click();
    await pageFixture.getByText('18', {
        exact: true
    }).click();
    await pageFixture.getByRole('button', {
        name: 'View'
    }).click();
    if (!Assigned_project_list.includes(Project_dtl.Project)) {
        // If the project is not in the Assigned_project_list
        await pageFixture.getByRole('option', {
            name: Project_dtl.Project
        }).click();
    } else {
        // If the project is already in the Assigned_project_list
        console.log("This project is already assigned to you");
    }
    await pageFixture.getByLabel('Add to Selected').click();
    await pageFixture.locator('#dateAddProjectFromDate-trigger-picker').click();
    await pageFixture.locator('.x-datepicker-month > .x-btn.x-unselectable.x-btn-default-small').nth(0).click();
    await pageFixture.getByRole('button', {
        name: Project_dtl.FromDate.substring(7),
        exact: true
    }).click();
    await pageFixture.getByRole('button', {
        name: Project_dtl.FromDate.substring(3, 6),
        exact: true
    }).click();
    await pageFixture.getByRole('button', {
        name: 'OK'
    }).click();
    await pageFixture.getByLabel('' + datesForPro["useDate1"]).getByText('' + datesForPro["dateNumber1"]).click();
    await pageFixture.locator('#dateAddProjectToDate-trigger-picker').click();
    await pageFixture.locator('.x-datepicker-month > .x-btn.x-unselectable.x-btn-default-small').nth(1).click();
    await pageFixture.getByRole('button', {
        name: Project_dtl.ToDate.substring(7),
        exact: true
    }).click();
    await pageFixture.getByRole('button', {
        name: Project_dtl.ToDate.substring(3, 6),
        exact: true
    }).click();
    await pageFixture.getByRole('button', {
        name: 'OK'
    }).click();
    await pageFixture.getByLabel('' + datesForPro["useDate2"]).getByText('' + datesForPro["dateNumber2"]).click();
    await pageFixture.getByRole('button', {
        name: 'View'
    }).click();
    await pageFixture.getByRole('option', {
        name: Project_dtl.Project
    }).click();
    await pageFixture.getByLabel('Add to Selected').click();
    // Check if arrays have same length
    if (modifiedArray.length !== Assigned_project_list.length) {
        await expect(true).toBe(true, "Assigned Projects are different");
    }
    // Sort both arrays
    const sortedArr1 = modifiedArray.slice().sort();
    const sortedArr2 = Assigned_project_list.slice().sort();
    let check_modifiedArray = true;
    // Compare sorted arrays element by element
    for (let i = 0; i < sortedArr1.length; i++) {
        if (sortedArr1[i] !== sortedArr2[i]) {
            check_modifiedArray = false;
            await expect(true).toBe(true, "Assigned Projects are different");
           
            break;
        }
    }
    // If all elements match, arrays are equal
    if (check_modifiedArray) {
        await expect(true).toBe(true, "Assigned Projects are same");
    }
    await pageFixture.waitForTimeout(2000);
});

ppm_login.skip('Projects assigned by manager', async({
        pageFixture
    }) => {
    let Assigned_project_list = [];
    const elementToRemove = "Vistaar Resource Pool (Dept : SDG)";
    if (assign_projects.includes(elementToRemove)) {
        const index = assign_projects.indexOf(elementToRemove);
        assign_projects.splice(index, 1);
    }
    const modifiedArray = assign_projects.map(project => project.split(' (')[0]);
    await pageFixture.getByRole('option', {
        name: Project_dtl.ProjectWeek
    }).click();
    await pageFixture.locator('.x-grid-item > tbody > .x-grid-row > .x-grid-cell.x-grid-td.x-grid-cell-gridcolumn-1078.x-unselectable > .x-grid-cell-inner').click();
    await pageFixture.locator('#TSEntryGrd_cmbProject-trigger-picker').click();
    let g = 0;
    let continueLoop = true;
    await pageFixture.getByText('Add New Project').click();
    await pageFixture.locator('#cmbAddProjectManager-trigger-picker').click();
    await pageFixture.getByLabel('Manager').fill(Project_dtl.Manager);
    await pageFixture.getByRole('option', {
        name: Project_dtl.Manager
    }).click();
    await pageFixture.locator('#dateAddProjectFromDate-trigger-picker').click();
    await pageFixture.getByText('18', {
        exact: true
    }).click();
    await pageFixture.getByRole('button', {
        name: 'View'
    }).click();
    try {
        while (g >= 0 && continueLoop) {
            const element = await pageFixture.waitForSelector('li[data-boundview="boundlist-1402"][data-recordindex="' + g + '"]', {
                timeout: 5000
            }); // Adjust timeout value as needed
            const textContent = await element.textContent();
            console.log("textContent:" + textContent);
            Assigned_project_list.push(textContent);
            g++;
        }
    } catch (error) {
        //console.error("Error occurred while locating element:", error);
        // Set continueLoop to false to exit the loop
        continueLoop = false;
    }
    // Check if arrays have same length
    if (modifiedArray.length !== Assigned_project_list.length) {
        await expect(true).toBe(true, "Assigned Projects are different");
    }
    console.log("modifiedArray: " + modifiedArray);
    console.log("Assigned_project_list: " + Assigned_project_list);
    // Sort both arrays
    const sortedArr1 = modifiedArray.slice().sort();
    const sortedArr2 = Assigned_project_list.slice().sort();
    let check_modifiedArray = true;
    // Compare sorted arrays element by element
    for (let i = 0; i < sortedArr1.length; i++) {
        if (sortedArr1[i] !== sortedArr2[i]) {
            check_modifiedArray = false;
            await expect(true).toBe(true, "Assigned Projects are different");
            
            break;
        }
    }
    // If all elements match, arrays are equal
    if (check_modifiedArray) {
        await expect(true).toBe(true, "Assigned Projects are same");
    }
    await pageFixture.waitForTimeout(2000);
});

ppm_login.skip('logout test success', async({
        pageFixture
    }) => {
    
    await pageFixture.locator('id=button-1025-btnInnerEl').click();
    await pageFixture.waitForTimeout(2000);
});