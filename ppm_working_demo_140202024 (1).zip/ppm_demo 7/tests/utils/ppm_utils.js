function getWeekRange(selectedDate) {
    const startDate = new Date(selectedDate);
    const endDate = new Date(selectedDate);
   
    console.log("selectedDate: "+selectedDate);
    console.log("startDate.getDate(): "+startDate.getDate());
    console.log((""));
    // Find the start of the week (Sunday)
    startDate.setDate(startDate.getDate() - startDate.getDay()+1);
  
    // Find the end of the week (Saturday)
    endDate.setDate(endDate.getDate() + (7 - endDate.getDay()));

    console.log("startDate of getWeekRange: "+startDate);
    console.log("endDate of getWeekeRange: "+endDate);
  
    // Format the dates
    const formattedStartDate = startDate.toLocaleDateString('en-GB', {
                day: '2-digit',
                month: 'short',
                year: '2-digit'
            }).replace(/ /g, '-');
    const formattedEndDate = endDate.toLocaleDateString('en-GB', {
                day: '2-digit',
                month: 'short',
                year: '2-digit'
            }).replace(/ /g, '-');
            console.log("formattedStartDate: "+formattedStartDate+" "+"formattedEndDate: "+formattedEndDate);
            return `${formattedStartDate} to ${formattedEndDate}`;
  }
  
 module.exports ={
    getWeekRange
 }