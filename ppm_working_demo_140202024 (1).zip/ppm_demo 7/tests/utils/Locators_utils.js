

async function locatorToBePresent(parentElement, childElement, pos ){
    const expectedPos = await parentElement.locator(childElement).nth(pos).count();
    console.log("expected: "+expectedPos);
    return expectedPos;
}

async function countNoOfChildElements(parentElement, childElement){
    const count = await parentElement.locator(childElement).count();
    console.log("No of child elements present in parent elements : "+count);
    return count;
}

module.exports = {
    locatorToBePresent, countNoOfChildElements
}